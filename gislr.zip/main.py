# from gislr_lightning.training import train
from gislr_tf.training import train

def main():
    module = train(
        val_fold=2,
        max_epochs=75,
        in_shape=(15,252),
        project='gislr_test',
        cross_validate=True,
        train_all=False,
    )
    pass

if __name__ == "__main__":
    main()