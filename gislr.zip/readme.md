## GPU Notes

22,919 MB per node

Log GPU usage in 1 sec intervals: `nvidia-smi dmon -s mu -d 5 -o TD`
Watch log file: `tail -n 25 -f logfile`

Pass: #Qa123456AI